package utils;

public class Endpoints {
    public static final String tutorialEndpoint="api/tutorials";
    //public static final String tutorialEndpoint1="api/tutorials";


}
